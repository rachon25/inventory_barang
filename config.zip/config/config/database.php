<?php
date_default_timezone_set('Asia/Jakarta');

$koneksi=new PDO('mysql:host=localhost;dbname=invenroty_barang', 
'root', '');

$koneksi->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$koneksi->query("SET time_zone='+7:00'");
?>