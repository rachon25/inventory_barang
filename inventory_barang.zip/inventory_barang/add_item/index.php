<?php
require '../../config/database.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $itemName = $_POST['item_name'];
    $uom = $_POST['uom'];
    $item_id = $_POST['item_id'];
    $createdAt = date("Y-m-d H:i:s");
    $note = "Tambah Nama Barang";
    $user = "nama User";
    $qty = 0;
    
    
    try {
        //validasi cek nama atau id name yang pernah di inputkan
        $checkStmt = $koneksi->prepare("SELECT COUNT(*) FROM items WHERE item_name=:item_name or item_id =:id_item");
        $checkStmt->bindParam(':id_item',$item_id);
        $checkStmt->bindParam(':item_name',$itemName);
        $checkStmt->execute();
        $doublecheck = $checkStmt->fetchcolumn();
        
        if ($doublecheck > 0) {
            echo "maaf barang yang anda add sudah ada di sistem.";
        } else {
        
        $stmt = $koneksi->prepare("INSERT INTO items (item_id,item_name,uom,created_at) VALUES (:item_id,:item_name, :uom, :created_at)");
        $stmt->bindParam(':item_id',$item_id);
        $stmt->bindParam(':item_name',$itemName);
        $stmt->bindParam(':uom',$uom);
        $stmt->bindParam(':created_at',$createdAt);
        $stmt->execute();
        
        $stmt_h = $koneksi->prepare("INSERT INTO item_history (id_item,qty,created_at,user,note) VALUES (:id_item,:qty,:created_at,:user, :note)");
        $stmt_h->bindParam(':id_item',$item_id);
        $stmt_h->bindParam(':qty',$qty);
        $stmt_h->bindParam(':created_at',$createdAt);
        $stmt_h->bindParam(':user',$user);
        $stmt_h->bindParam(':note',$note);
        $stmt_h->execute();
    
        header("location:/inventory_barang");
        exit();
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
}
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <h4>TAMBAH BARANG</h4>
    <form action ="" method="post">
        <label for="item_id"> Item ID:</label>
        <input type="text" id="item_id" name="item_id" required><br><br>
        
        <label for="item_name"> Item Name:</label>
        <input type="text" id="item_name" name="item_name" required><br><br>
        
        <label for="uom">UoM</label>
        <input type="text" id="uom" name="uom" required><br><br>
        
        <button type="submit">Tambah Barang</button>
        <button type="button" onclick="location.href='/inventory_barang'">Batal</button>
    </form>
  
</body>    
</html>
