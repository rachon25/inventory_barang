<!DOCTYPE html>
<html>

<head>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ddd;
        }

        th,
        td {
            text-align: left;
            padding: 16px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <div class="c-data">
        <h4>DATA ITEM</h4>
        <a href="add_item/">tambah barang</a>
        <button onclick='location.href=item_in'>input barang masuk</button>
        <button onclick='location.href=item_out'>input barang keluar</button>
        <button onclick='location.href=item_stockils'>stock list</button>
        <table>
            <tr>
                <th>No</th>
                <th>PART NO</th>
                <th>ITEM NAME</th>
                <th>UOM</th>
                <th>CREATE DATE</th>
                <th>OPTION</th>

            </tr>
            <tr>
                <?php
                require '../config/database.php';
                try {
                    $start = 0;
                    $data = $koneksi->query("SELECT * FROM items");
                    $i = $start + 1;
                    while ($resDat = $data->fetch(PDO::FETCH_ASSOC)) {
                        echo "<td>" . $i . "</td>";
                        echo "<td><a href='../inventory_barang/item_detail/?id={$resDat['item_id']}'>" . $resDat["item_id"] . "</a></td>";
                        echo "<td>" . $resDat["item_name"] . "</td>";
                        echo "<td>" . $resDat["uom"] . "</td>";
                        echo "<td>" . $resDat["created_at"] . "</td>";
                        echo "<td><button onclick='location.href='update_item?id={$resDat['id']}'\">Update</button>
            <button onclick=\"if(comfirm('apakah yakin di delete?')) location.href='delete?id={$resDat['id']}'\">Delete</button></td></tr>";
                        $i++;
                    }
                } catch (PDOException $e) {
                    print $e->getMessage();
                    die();
                }
                ?>
        </table>
</body>

</html>