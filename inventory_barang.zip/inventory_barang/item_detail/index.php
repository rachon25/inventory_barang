<?php
    require '../../config/database.php';
        if(isset ($_GET['id'])) {
            $item_id = $_GET['id'] ;
            try {
                $stmt = $koneksi->prepare("SELECT i.item_id, i.item_name,i.uom,COALESCE(SUM(inn.qty), 0) AS barang_masuk,COALESCE(SUM(out_i.qty),0) AS barang_keluar,COALESCE(SUM(inn.qty), 0) - COALESCE(SUM(out_i.qty), 0) AS stock FROM items AS i
                    LEFT JOIN 
                        items_in AS inn ON i.item_id = inn.id_item
                    LEFT JOIN 
                        item_out AS out_i ON i.item_id = out_i.id_item
                    WHERE i.item_id = item_id
                    GROUP BY i.item_id");
                $stmt->bindParam('item_id',$item_id);
                $stmt->execute();
                $itemDetail = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$itemDetail) {
                    echo "<p> Item Tidak Ketemu </p>";
                    exit();
                }
            } catch (PDOException $e) {
                    echo "error" . $e->getMessage();
                }
        } else {
            echo "<p> Kesalahan Req. Part No tidak ada.</p>";
            exit();
}
?>
<!DOCTYPE html>
<html>

<head>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ddd;
        }

        th,
        td {
            text-align: left;
            padding: 16px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <div class="c-data">
        <h4>DETAIL ITEM</h4>
        <table>
            <tr>
                <th>PART NO</th>
                <th>ITEM NAME</th>
                <th>UOM</th>
                <th>ITEM IN</th></th>
                <th>ITEM OUT</th>
                <th>STOCK</th>
                <th>OPTION</th>
            </tr>
            
            <tr>
                <td><?php echo htmlspecialchars($itemDetail['item_id']); ?> </td>
                <td><?php echo htmlspecialchars($itemDetail['item_name']); ?> </td>
                <td><?php echo htmlspecialchars($itemDetail['uom']); ?> </td>
                <td><?php echo htmlspecialchars($itemDetail['barang_masuk']); ?> </td>
                <td><?php echo htmlspecialchars($itemDetail['barang_keluar']); ?> </td>
                <td><?php echo htmlspecialchars($itemDetail['stock']); ?> </td>
                <td><a>History</a></td>
            </tr>
        </table>
</body>

</html>